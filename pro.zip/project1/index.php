<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>cvam0000</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Custom styles for this template -->
    <link href="css/modern-business.css" rel="stylesheet">
<style>
img {

    object-fit:cover;
}
</style>
  </head>

  <body>

    <!-- Navigation -->
    <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="index.html"><b>Company</b></a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="about.html">About</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="services.html">Services</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="contact.html">Contact</a>
            </li>


            <li class="nav-item">
              <a class="nav-link" href="login.php"><i class="fa fa-sign-in" style="font-size:15px">  </i> Login</a>
            </li>


          </ul>
        </div>
      </div>
    </nav>

    <header>
      <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
          <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner" role="listbox">

          <div class="carousel-item active" style="background-image: url('https://www.desktopbackground.org/download/o/2011/01/30/149991_top-red-tech-wallpapers-hd-images-for-pinterest_1920x1080_h.jpg')">
            <div class="carousel-caption d-none d-md-block">

              <p>This is a description </p>
            </div>
          </div>

          <div class="carousel-item" style="background-image: url('https://www.desktopbackground.org/download/o/2011/01/30/149991_top-red-tech-wallpapers-hd-images-for-pinterest_1920x1080_h.jpg')">
            <div class="carousel-caption d-none d-md-block">

              <p>This is a description </p>
            </div>
          </div>

          <div class="carousel-item" style="background-image: url('https://www.desktopbackground.org/download/o/2011/01/30/149991_top-red-tech-wallpapers-hd-images-for-pinterest_1920x1080_h.jpg')">
            <div class="carousel-caption d-none d-md-block">

              <p>This is a description </p>
            </div>
          </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
      </div>
    </header>
<br><br><br>
    <!-- Page Content -->
    <div class="container">


      <!-- Portfolio Section -->
      <h2>Gallery</h2>




<div class="row">

<?php
include 'conn.php';
$sql = mysqli_query($conn, "SELECT * FROM images ORDER BY id DESC");
    while($row=mysqli_fetch_array($sql))
        {


        echo"

            <div class='col-lg-4 col-sm-6 portfolio-item'>
              <div class='card h-100'>
                <a href='#'><img class='card-img-top'    src='pics/".$row['image']."'     ></a>
                  <div class='card-body'>
                  <h4 class='card-title'>
                    <a href='#'>".$row['title']."  </a>
                  </h4>
                  <p class='card-text'>".$row['description']."</p>
                </div>
              </div>
            </div>";
          }



        ?>














      </div>
      <!-- /.row -->

      <!-- Features Section -->
      <div class="row">
        <div class="col-lg-6">
          <h2>Our Features</h2>
          <p>We are here to help you:</p>
          <ul>
            <li>
              <strong>cvam0000</strong>
            </li>
            <li>aasdfghjk</li>
            <li>asdfghjk</li>
            <li>asdfghjklkjhgfds</li>
            <li>qwertyuiopiuytrew</li>
          </ul>
          <p>jshh hvsv sbd sks dmsnbdij skdbs dnvsihd jnvdu sd jdish dsbjdn sjndbhs dkbsiud skbdi skdbisbkmd skbd smk dkjbs</p>
        </div>
        <div class="col-lg-6">
          <img class="img-fluid rounded" src="https://www.diplateevo.com/wp-content/uploads/2012/02/tech-tshirt.png" alt="">
        </div>
      </div>
      <!-- /.row -->

      <hr>

      <!-- Call to Action Section -->
      <div class="row mb-4">
        <div class="col-md-8">
          <p>jcvhugc jgb fn if bfk kfgsdn f js  njbb dknsbjid bigk l/cbjod cbdbc k;bc c dbcibdk ckbdhc knbcjbnsnkm cjbjc jshcbskn kjbc dm kcd  lknn lnokc kjcnkm m,ckjs .</p>
        </div>
        <div class="col-md-4">
          <a class="btn btn-lg btn-secondary btn-block" href="#">Call to Action</a>
        </div>
      </div>

    </div>
    <!-- /.container -->



    <footer class="footer-distributed">

    			<div class="footer-left">

    				<h3>Company<span>logo</span></h3>

    				<p class="footer-links">
    					<a href="#" class="link-1">Home</a>

    					<a href="#">Blog</a>


    					<a href="#">About</a>

    					<a href="#">Login</a>

    					<a href="#">Contact</a>
    				</p>

    				<p class="footer-company-name">Company  © 2018</p>
    			</div>

    			<div class="footer-center">

    				<div>
    					<i class="fa fa-map-marker"></i>
    					<p><span>ABCD</span> Palam</p>
    				</div>

    				<div>
    					<i class="fa fa-phone"></i>
    					<p>+91.555.555.5555</p>
    				</div>

    				<div>
    					<i class="fa fa-envelope"></i>
    					<p><a href="cvam0000t@company.com">support@company.com</a></p>
    				</div>

    			</div>

    			<div class="footer-right">

    				<p class="footer-company-about">
    					<span>About the company</span>
    					we are a company
    				</p>

    				<div class="footer-icons">

    					<a href="#"><i class="fa fa-facebook"></i></a>
    					<a href="#"><i class="fa fa-twitter"></i></a>
    					<a href="#"><i class="fa fa-linkedin"></i></a>
    					<a href="#"><i class="fa fa-github"></i></a>

    				</div>

    			</div>

    		</footer>






    <!-- Footer -->
    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; 2018</p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>

</html>
